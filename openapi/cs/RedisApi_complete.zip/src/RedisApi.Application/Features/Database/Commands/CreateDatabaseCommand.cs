using MediatR;
using System.Collections.Generic;
using RedisApi.Domain.Entities;

namespace RedisApi.Application.Features.Database.Commands
{
    public class CreateDatabaseCommand : IRequest<Database>
    {
        public string AppId { get; set; }
        public string Lob { get; set; }
        public string Environment { get; set; }
        public List<string> Modules { get; set; }
        public string Email { get; set; }
        public string Ticket { get; set; }
        public bool CRDB { get; set; }
        public string TlsOu { get; set; }
        public string TlsCn { get; set; }
        public List<string> Datacenters { get; set; }
    }
}
