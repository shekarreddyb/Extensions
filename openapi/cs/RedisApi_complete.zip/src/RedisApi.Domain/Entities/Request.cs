using System;
using System.Collections.Generic;

namespace RedisApi.Domain.Entities
{
    public class Request
    {
        public Guid Id { get; set; }
        public string Operation { get; set; }
        public string Status { get; set; }
        public string Message { get; set; }
        public DateTime CreatedOn { get; set; }
        public string CreatedBy { get; set; }
        public List<RequestDetail> Details { get; set; } = new();
    }
}
