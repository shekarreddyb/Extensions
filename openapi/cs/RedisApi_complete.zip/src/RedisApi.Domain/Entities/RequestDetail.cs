using System;

namespace RedisApi.Domain.Entities
{
    public class RequestDetail
    {
        public Guid Id { get; set; }
        public Guid RequestId { get; set; }
        public string Status { get; set; }
        public string Message { get; set; }
    }
}
