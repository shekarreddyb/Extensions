
public class OperationTaskSaga : MassTransitStateMachine<OperationTaskState>
{
    public State Running { get; private set; }
    public State Completed { get; private set; }
    public State Failed { get; private set; }

    public Event<StartProvisioningTask> TaskStarted { get; private set; }
    public Event<PollProvisioningTask> PollRequested { get; private set; }
    public Event<TaskSucceeded> Succeeded { get; private set; }
    public Event<TaskFailed> FailedEvent { get; private set; }

    public Schedule<OperationTaskState, PollProvisioningTask> PollSchedule { get; private set; }

    public OperationTaskSaga(IRedisApiService redis)
    {
        InstanceState(x => x.CurrentState);

        Event(() => TaskStarted, x => x.CorrelateById(m => m.OperationTaskId));
        Event(() => PollRequested, x => x.CorrelateById(m => m.OperationTaskId));
        Event(() => Succeeded, x => x.CorrelateById(m => m.OperationTaskId));
        Event(() => FailedEvent, x => x.CorrelateById(m => m.OperationTaskId));

        Schedule(() => PollSchedule, x => x.PollTokenId, s =>
        {
            s.Delay = TimeSpan.FromSeconds(10);
            s.Received = x => x.CorrelateById(m => m.OperationTaskId);
        });

        Initially(
            When(TaskStarted)
                .ThenAsync(async context =>
                {
                    var externalId = await redis.StartOperationAsync(context.Data.Operation);
                    context.Instance.ExternalTaskId = externalId;
                    context.Instance.Status = "Running";
                })
                .TransitionTo(Running)
                .Schedule(PollSchedule,
                    ctx => new PollProvisioningTask { OperationTaskId = ctx.Instance.CorrelationId },
                    ctx => TimeSpan.FromSeconds(10))
        );

        During(Running,
            When(PollRequested)
                .ThenAsync(async context =>
                {
                    var status = await redis.CheckStatusAsync(context.Instance.ExternalTaskId!);
                    if (status == "Success")
                    {
                        await context.Publish(new TaskSucceeded
                        {
                            OperationTaskId = context.Instance.CorrelationId,
                            TransactionId = context.Instance.TransactionId,
                            DatabaseId = context.Instance.DatabaseId,
                            ClusterId = context.Instance.ClusterId,
                            Operation = context.Instance.Operation
                        });
                    }
                    else if (status == "Failed")
                    {
                        await context.Publish(new TaskFailed
                        {
                            OperationTaskId = context.Instance.CorrelationId,
                            TransactionId = context.Instance.TransactionId,
                            DatabaseId = context.Instance.DatabaseId,
                            ClusterId = context.Instance.ClusterId,
                            Operation = context.Instance.Operation,
                            Message = "Redis operation failed"
                        });
                    }
                    else
                    {
                        await context.Schedule(PollSchedule,
                            new PollProvisioningTask { OperationTaskId = context.Instance.CorrelationId },
                            TimeSpan.FromSeconds(10));
                    }
                })
        );

        During(Running,
            When(Succeeded)
                .Then(ctx => ctx.Instance.Status = "Completed")
                .TransitionTo(Completed)
        );

        During(Running,
            When(FailedEvent)
                .Then(ctx => ctx.Instance.Status = "Failed")
                .TransitionTo(Failed)
        );
    }
}
