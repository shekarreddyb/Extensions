
public class OperationTaskState : SagaStateMachineInstance
{
    public Guid CorrelationId { get; set; }
    public Guid TransactionId { get; set; }
    public Guid DatabaseId { get; set; }
    public Guid ClusterId { get; set; }
    public string Operation { get; set; } = default!;
    public string Status { get; set; } = "Pending";
    public string? ExternalTaskId { get; set; }
    public string CurrentState { get; set; } = default!;
    public Guid? PollTokenId { get; set; }
    public int Sequence { get; set; }
}
