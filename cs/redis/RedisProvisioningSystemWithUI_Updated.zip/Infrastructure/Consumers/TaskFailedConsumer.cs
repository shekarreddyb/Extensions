
public class TaskFailedConsumer : IConsumer<TaskFailed>
{
    private readonly IProvisioningDbContext _db;

    public TaskFailedConsumer(IProvisioningDbContext db) => _db = db;

    public async Task Consume(ConsumeContext<TaskFailed> context)
    {
        var msg = context.Message;

        var task = await _db.OperationTasks.FindAsync(msg.OperationTaskId);
        if (task != null)
        {
            task.Status = "Failed";
            task.CompletedAt = DateTime.UtcNow;
            task.Message = msg.Message;
        }

        var transDetail = _db.TransactionDetails
            .FirstOrDefault(td => td.TransactionId == msg.TransactionId && td.ClusterId == msg.ClusterId && td.Operation == msg.Operation);
        if (transDetail != null)
        {
            transDetail.Status = "Failed";
            transDetail.EndTime = DateTime.UtcNow;
            transDetail.Message = msg.Message;
        }

        var db = await _db.Databases.FindAsync(msg.DatabaseId);
        if (db != null)
        {
            db.Status = "Failed";
        }

        var txn = await _db.Transactions.FindAsync(msg.TransactionId);
        if (txn != null)
        {
            txn.EndTime = DateTime.UtcNow;
            txn.Operation += " (Failed)";
        }

        await _db.SaveChangesAsync();
    }
}
