
public interface IRedisApiService
{
    Task<string> StartOperationAsync(string operationType);
    Task<string> CheckStatusAsync(string externalId);
    Task<bool> PingAsync();
}

public class RedisApiService : IRedisApiService
{
    public async Task<string> StartOperationAsync(string operationType)
    {
        await Task.Delay(100); // simulate network latency
        return Guid.NewGuid().ToString(); // simulate returned Redis task ID
    }

    public async Task<string> CheckStatusAsync(string externalId)
    {
        await Task.Delay(100);
        var r = new Random().Next(0, 10);
        return r switch
        {
            < 6 => "Pending",
            < 9 => "Success",
            _ => "Failed"
        };
    }

    public Task<bool> PingAsync() => Task.FromResult(true);
}
