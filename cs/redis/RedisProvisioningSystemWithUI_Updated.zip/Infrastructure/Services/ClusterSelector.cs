
public interface IClusterSelector
{
    Task<Cluster?> SelectBestClusterAsync(string datacenterId, string environment);
}

public class ClusterSelector : IClusterSelector
{
    private readonly IProvisioningDbContext _db;

    public ClusterSelector(IProvisioningDbContext db) => _db = db;

    public async Task<Cluster?> SelectBestClusterAsync(string datacenterId, string environment)
    {
        return await _db.Clusters
            .Where(c => c.Environment == environment && c.DatacenterId.ToString() == datacenterId)
            .OrderBy(c => c.Capacity)
            .FirstOrDefaultAsync();
    }
}
