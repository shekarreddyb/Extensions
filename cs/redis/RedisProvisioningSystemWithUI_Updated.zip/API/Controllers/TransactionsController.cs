
[ApiController]
[Route("api/transactions")]
public class TransactionsController : ControllerBase
{
    private readonly IProvisioningDbContext _db;

    public TransactionsController(IProvisioningDbContext db) => _db = db;

    [HttpGet("{transactionId}")]
    public async Task<IActionResult> GetTransactionDetails(Guid transactionId)
    {
        var tx = await _db.Transactions
            .Include(t => t.Details)
            .Include(t => t.ChangeLogs)
            .FirstOrDefaultAsync(t => t.Id == transactionId);

        if (tx == null) return NotFound();

        return Ok(new
        {
            tx.Ticket,
            tx.Operation,
            tx.StartTime,
            tx.EndTime,
            Changes = tx.ChangeLogs.Select(c => new { c.Field, c.OldValue, c.NewValue }),
            Steps = tx.Details.Select(d => new
            {
                d.Operation,
                d.ClusterId,
                d.Status,
                d.Message,
                d.StartTime,
                d.EndTime
            })
        });
    }
}
