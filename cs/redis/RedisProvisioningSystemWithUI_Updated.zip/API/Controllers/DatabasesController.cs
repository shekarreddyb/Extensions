
[ApiController]
[Route("api/databases")]
public class DatabasesController : ControllerBase
{
    private readonly IProvisioningDbContext _db;
    private readonly IMediator _mediator;

    public DatabasesController(IProvisioningDbContext db, IMediator mediator)
    {
        _db = db;
        _mediator = mediator;
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> GetDatabase(Guid id)
    {
        var db = await _db.Databases
            .Include(d => d.DatabaseDetails)
            .Include(d => d.TlsConfig)
            .FirstOrDefaultAsync(d => d.Id == id);

        if (db == null) return NotFound();

        return Ok(new
        {
            db.Id,
            db.Name,
            db.AppId,
            db.SubAppId,
            db.Environment,
            db.Memory,
            db.ShardsCount,
            db.Status,
            Modules = db.Modules.Select(m => m.Name),
            TLS = db.TlsConfig.Select(t => new { t.OU, t.CN }),
            Clusters = db.DatabaseDetails.Select(dd => new
            {
                dd.ClusterId,
                dd.Status,
                dd.Endpoint,
                dd.Uid
            })
        });
    }

    [HttpPost("create")]
    public async Task<IActionResult> Create([FromBody] CreateDatabaseCommand command)
    {
        var txnId = await _mediator.Send(command);
        return Accepted(new { TransactionId = txnId });
    }

    [HttpPut("{id}/update")]
    public async Task<IActionResult> Update(Guid id, [FromBody] UpdateDatabaseCommand command)
    {
        var txnId = await _mediator.Send(command with { DatabaseId = id });
        return Accepted(new { TransactionId = txnId });
    }

    [HttpGet("{id}/transactions")]
    public async Task<IActionResult> GetDatabaseTransactions(Guid id)
    {
        var txns = await _db.Transactions
            .Where(t => t.DatabaseId == id)
            .OrderByDescending(t => t.StartTime)
            .ToListAsync();

        return Ok(txns.Select(t => new
        {
            t.Id,
            t.Ticket,
            t.Operation,
            t.StartTime,
            t.EndTime
        }));
    }
}
