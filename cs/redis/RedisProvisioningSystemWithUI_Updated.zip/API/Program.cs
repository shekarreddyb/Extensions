
var builder = WebApplication.CreateBuilder(args);

builder.Host.UseSerilog((ctx, lc) =>
{
    lc.ReadFrom.Configuration(ctx.Configuration).Enrich.FromLogContext();
});

builder.Services.AddDbContext<ProvisioningDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

builder.Services.AddScoped<IProvisioningDbContext>(sp => sp.GetRequiredService<ProvisioningDbContext>());
builder.Services.AddScoped<IRedisApiService, RedisApiService>();
builder.Services.AddScoped<IClusterSelector, ClusterSelector>();
builder.Services.AddMediatR(typeof(CreateDatabaseCommandHandler).Assembly);

builder.Services.AddMassTransit(x =>
{
    x.AddSagaStateMachine<OperationTaskSaga, OperationTaskState>()
     .EntityFrameworkRepository(r =>
     {
         r.ConcurrencyMode = ConcurrencyMode.Pessimistic;
         r.AddDbContext<DbContext, ProvisioningDbContext>((provider, cfg) =>
             cfg.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));
     });

    x.AddConsumer<TaskSucceededConsumer>();
    x.AddConsumer<TaskFailedConsumer>();

    x.UsingInMemory((ctx, cfg) =>
    {
        cfg.UseQuartzScheduler();
        cfg.ConfigureEndpoints(ctx);
    });
});

builder.Services.AddMassTransitHostedService();
builder.Services.AddQuartzHostedService();

builder.Services.AddHealthChecks()
    .AddDbContextCheck<ProvisioningDbContext>("SQL DB")
    .AddCheck<RedisApiHealthCheck>("Redis API")
    .AddCheck<BusHealthCheck>("MassTransit Bus")
    .ForwardToPrometheus();

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

app.UseSerilogRequestLogging();
app.UseRouting();
app.UseAuthorization();
app.UseSwagger();
app.UseSwaggerUI();

app.MapControllers();
app.MapHealthChecks("/health");
app.MapPrometheusScrapingEndpoint("/metrics");

app.Run();
