
public class Transaction
{
    public Guid Id { get; set; }
    public string Ticket { get; set; } = default!;
    public string Operation { get; set; } = default!;
    public DateTime StartTime { get; set; }
    public DateTime? EndTime { get; set; }
    public Guid DatabaseId { get; set; }
    public List<TransactionDetail> Details { get; set; } = new();
    public List<TransactionChangeLog> ChangeLogs { get; set; } = new();
}
