
public class Cluster
{
    public Guid Id { get; set; }
    public Guid DatacenterId { get; set; }
    public string Environment { get; set; } = default!;
    public long Capacity { get; set; }
    public string ClusterUrl { get; set; } = default!;
}
