
public class OperationTask
{
    public Guid Id { get; set; }
    public Guid TransactionId { get; set; }
    public Guid DatabaseId { get; set; }
    public Guid ClusterId { get; set; }
    public string Operation { get; set; } = default!;
    public string Status { get; set; } = "Pending";
    public int Sequence { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? CompletedAt { get; set; }
    public string? Message { get; set; }
}
