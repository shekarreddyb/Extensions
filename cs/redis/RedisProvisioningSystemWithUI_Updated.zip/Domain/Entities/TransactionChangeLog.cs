
public class TransactionChangeLog
{
    public Guid Id { get; set; }
    public Guid TransactionId { get; set; }
    public string Field { get; set; } = default!;
    public string? OldValue { get; set; }
    public string? NewValue { get; set; }
    public DateTime ChangedAt { get; set; }
}
