
public class TlsConfig
{
    public string OU { get; set; } = default!;
    public string CN { get; set; } = default!;
}
