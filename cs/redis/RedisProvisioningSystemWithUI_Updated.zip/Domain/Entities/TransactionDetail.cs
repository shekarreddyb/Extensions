
public class TransactionDetail
{
    public Guid Id { get; set; }
    public Guid TransactionId { get; set; }
    public Guid ClusterId { get; set; }
    public string Operation { get; set; } = default!;
    public string Status { get; set; } = "Pending";
    public string Message { get; set; } = string.Empty;
    public DateTime StartTime { get; set; }
    public DateTime? EndTime { get; set; }
}
