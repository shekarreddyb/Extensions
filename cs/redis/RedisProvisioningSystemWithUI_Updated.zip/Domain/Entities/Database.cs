
public class Database
{
    public Guid Id { get; set; }
    public string Name { get; set; } = default!;
    public string AppId { get; set; } = default!;
    public string SubAppId { get; set; } = default!;
    public string Environment { get; set; } = default!;
    public List<DbModule> Modules { get; set; } = new();
    public long Memory { get; set; }
    public int ShardsCount { get; set; }
    public string Status { get; set; } = "Pending";
    public List<TlsConfig> TlsConfig { get; set; } = new();
    public List<DatabaseDetail> DatabaseDetails { get; set; } = new();
}

public class DbModule
{
    public string Name { get; set; } = default!;
}
