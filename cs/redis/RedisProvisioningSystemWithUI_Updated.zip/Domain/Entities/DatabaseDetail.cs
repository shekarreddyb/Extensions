
public class DatabaseDetail
{
    public Guid Id { get; set; }
    public Guid DatabaseId { get; set; }
    public int? Uid { get; set; }
    public Guid ClusterId { get; set; }
    public string Endpoint { get; set; } = string.Empty;
    public string Status { get; set; } = "Pending";
}
