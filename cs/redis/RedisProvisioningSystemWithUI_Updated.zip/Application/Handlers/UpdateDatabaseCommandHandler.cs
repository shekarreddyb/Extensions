
public class UpdateDatabaseCommandHandler : IRequestHandler<UpdateDatabaseCommand, Guid>
{
    private readonly IProvisioningDbContext _db;
    private readonly IPublishEndpoint _publisher;
    private readonly IClusterSelector _clusterSelector;

    public UpdateDatabaseCommandHandler(
        IProvisioningDbContext db,
        IPublishEndpoint publisher,
        IClusterSelector clusterSelector)
    {
        _db = db;
        _publisher = publisher;
        _clusterSelector = clusterSelector;
    }

    public async Task<Guid> Handle(UpdateDatabaseCommand request, CancellationToken cancellationToken)
    {
        var db = await _db.Databases.Include(d => d.TlsConfig).FirstOrDefaultAsync(x => x.Id == request.DatabaseId);
        if (db == null) throw new Exception("Database not found");

        var txnId = Guid.NewGuid();
        var sequence = 1;
        var clusterIds = _db.DatabaseDetails.Where(d => d.DatabaseId == db.Id).Select(d => d.ClusterId).ToList();

        var transaction = new Transaction
        {
            Id = txnId,
            Ticket = $"UPD-{DateTime.UtcNow:yyyyMMddHHmmss}-{Guid.NewGuid().ToString()[..6]}",
            Operation = "Update",
            StartTime = DateTime.UtcNow,
            DatabaseId = db.Id
        };

        // Memory update
        if (request.NewMemory.HasValue && request.NewMemory != db.Memory)
        {
            transaction.ChangeLogs.Add(new TransactionChangeLog
            {
                Id = Guid.NewGuid(),
                TransactionId = txnId,
                Field = "Memory",
                OldValue = db.Memory.ToString(),
                NewValue = request.NewMemory.Value.ToString(),
                ChangedAt = DateTime.UtcNow
            });

            foreach (var clusterId in clusterIds)
            {
                var taskId = Guid.NewGuid();
                _db.OperationTasks.Add(new OperationTask
                {
                    Id = taskId,
                    TransactionId = txnId,
                    DatabaseId = db.Id,
                    ClusterId = clusterId,
                    Operation = "UpdateMemory",
                    Status = "Pending",
                    Sequence = sequence++,
                    CreatedAt = DateTime.UtcNow
                });

                transaction.Details.Add(new TransactionDetail
                {
                    Id = Guid.NewGuid(),
                    TransactionId = txnId,
                    ClusterId = clusterId,
                    Operation = "UpdateMemory",
                    Status = "Pending",
                    StartTime = DateTime.UtcNow
                });

                await _publisher.Publish(new StartProvisioningTask
                {
                    OperationTaskId = taskId,
                    TransactionId = txnId,
                    DatabaseId = db.Id,
                    ClusterId = clusterId,
                    Operation = "UpdateMemory",
                    Sequence = sequence
                });
            }

            db.Memory = request.NewMemory.Value;
        }

        // Add TLS certs
        if (request.AddCerts != null)
        {
            foreach (var cert in request.AddCerts)
            {
                if (!db.TlsConfig.Any(x => x.OU == cert.OU && x.CN == cert.CN))
                {
                    db.TlsConfig.Add(cert);
                    transaction.ChangeLogs.Add(new TransactionChangeLog
                    {
                        Id = Guid.NewGuid(),
                        TransactionId = txnId,
                        Field = "TlsCerts",
                        OldValue = null,
                        NewValue = $"Add:{cert.OU}-{cert.CN}",
                        ChangedAt = DateTime.UtcNow
                    });

                    foreach (var clusterId in clusterIds)
                    {
                        var taskId = Guid.NewGuid();
                        _db.OperationTasks.Add(new OperationTask
                        {
                            Id = taskId,
                            TransactionId = txnId,
                            DatabaseId = db.Id,
                            ClusterId = clusterId,
                            Operation = "AddTlsCert",
                            Status = "Pending",
                            Sequence = sequence++,
                            CreatedAt = DateTime.UtcNow
                        });

                        transaction.Details.Add(new TransactionDetail
                        {
                            Id = Guid.NewGuid(),
                            TransactionId = txnId,
                            ClusterId = clusterId,
                            Operation = "AddTlsCert",
                            Status = "Pending",
                            StartTime = DateTime.UtcNow
                        });

                        await _publisher.Publish(new StartProvisioningTask
                        {
                            OperationTaskId = taskId,
                            TransactionId = txnId,
                            DatabaseId = db.Id,
                            ClusterId = clusterId,
                            Operation = "AddTlsCert",
                            Sequence = sequence
                        });
                    }
                }
            }
        }

        // Remove TLS certs
        if (request.RemoveCerts != null)
        {
            foreach (var cert in request.RemoveCerts)
            {
                var existing = db.TlsConfig.FirstOrDefault(x => x.OU == cert.OU && x.CN == cert.CN);
                if (existing != null)
                {
                    db.TlsConfig.Remove(existing);
                    transaction.ChangeLogs.Add(new TransactionChangeLog
                    {
                        Id = Guid.NewGuid(),
                        TransactionId = txnId,
                        Field = "TlsCerts",
                        OldValue = $"Remove:{cert.OU}-{cert.CN}",
                        NewValue = null,
                        ChangedAt = DateTime.UtcNow
                    });

                    foreach (var clusterId in clusterIds)
                    {
                        var taskId = Guid.NewGuid();
                        _db.OperationTasks.Add(new OperationTask
                        {
                            Id = taskId,
                            TransactionId = txnId,
                            DatabaseId = db.Id,
                            ClusterId = clusterId,
                            Operation = "RemoveTlsCert",
                            Status = "Pending",
                            Sequence = sequence++,
                            CreatedAt = DateTime.UtcNow
                        });

                        transaction.Details.Add(new TransactionDetail
                        {
                            Id = Guid.NewGuid(),
                            TransactionId = txnId,
                            ClusterId = clusterId,
                            Operation = "RemoveTlsCert",
                            Status = "Pending",
                            StartTime = DateTime.UtcNow
                        });

                        await _publisher.Publish(new StartProvisioningTask
                        {
                            OperationTaskId = taskId,
                            TransactionId = txnId,
                            DatabaseId = db.Id,
                            ClusterId = clusterId,
                            Operation = "RemoveTlsCert",
                            Sequence = sequence
                        });
                    }
                }
            }
        }

        _db.Transactions.Add(transaction);
        await _db.SaveChangesAsync();
        return txnId;
    }
}
