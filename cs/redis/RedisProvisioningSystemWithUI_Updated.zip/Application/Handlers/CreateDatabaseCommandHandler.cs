
public class CreateDatabaseCommandHandler : IRequestHandler<CreateDatabaseCommand, Guid>
{
    private readonly IProvisioningDbContext _db;
    private readonly IPublishEndpoint _publisher;
    private readonly IClusterSelector _clusterSelector;

    public CreateDatabaseCommandHandler(
        IProvisioningDbContext db,
        IPublishEndpoint publisher,
        IClusterSelector clusterSelector)
    {
        _db = db;
        _publisher = publisher;
        _clusterSelector = clusterSelector;
    }

    public async Task<Guid> Handle(CreateDatabaseCommand request, CancellationToken cancellationToken)
    {
        var dbId = Guid.NewGuid();
        var txnId = Guid.NewGuid();
        var sequence = 1;

        var dbName = $"{request.AppId}-{request.SubAppId}-{request.Environment}-{Guid.NewGuid():N}".Substring(0, 30);

        var database = new Database
        {
            Id = dbId,
            Name = dbName,
            AppId = request.AppId,
            SubAppId = request.SubAppId,
            Environment = request.Environment,
            Modules = request.Modules.Select(m => new DbModule { Name = m }).ToList(),
            Memory = request.Memory,
            ShardsCount = request.ShardsCount,
            TlsConfig = request.TlsConfig,
            Status = "Pending"
        };

        var transaction = new Transaction
        {
            Id = txnId,
            Ticket = $"REQ-{DateTime.UtcNow:yyyyMMddHHmmss}-{Guid.NewGuid().ToString()[..6]}",
            Operation = "Create",
            StartTime = DateTime.UtcNow,
            DatabaseId = dbId
        };

        foreach (var dc in request.DatacenterList)
        {
            var cluster = await _clusterSelector.SelectBestClusterAsync(dc, request.Environment);
            if (cluster == null) continue;

            var dbDetail = new DatabaseDetail
            {
                Id = Guid.NewGuid(),
                DatabaseId = dbId,
                ClusterId = cluster.Id,
                Status = "Pending"
            };
            _db.DatabaseDetails.Add(dbDetail);

            var taskId = Guid.NewGuid();
            _db.OperationTasks.Add(new OperationTask
            {
                Id = taskId,
                TransactionId = txnId,
                DatabaseId = dbId,
                ClusterId = cluster.Id,
                Operation = "CreateDatabase",
                Status = "Pending",
                Sequence = sequence++,
                CreatedAt = DateTime.UtcNow
            });

            transaction.Details.Add(new TransactionDetail
            {
                Id = Guid.NewGuid(),
                TransactionId = txnId,
                ClusterId = cluster.Id,
                Operation = "CreateDatabase",
                Status = "Pending",
                StartTime = DateTime.UtcNow
            });

            await _publisher.Publish(new StartProvisioningTask
            {
                OperationTaskId = taskId,
                TransactionId = txnId,
                DatabaseId = dbId,
                ClusterId = cluster.Id,
                Operation = "CreateDatabase",
                Sequence = sequence
            });
        }

        _db.Databases.Add(database);
        _db.Transactions.Add(transaction);
        await _db.SaveChangesAsync();
        return txnId;
    }
}
