
public record UpdateDatabaseCommand(
    Guid DatabaseId,
    long? NewMemory,
    int? NewShards,
    List<TlsConfig>? AddCerts,
    List<TlsConfig>? RemoveCerts,
    List<string>? AddClusters,
    List<string>? RemoveClusters
) : IRequest<Guid>;
