
public record CreateDatabaseCommand(
    string AppId,
    string SubAppId,
    string Environment,
    List<string> Modules,
    long Memory,
    int ShardsCount,
    List<TlsConfig> TlsConfig,
    bool IsCrdb,
    List<string> DatacenterList
) : IRequest<Guid>;
