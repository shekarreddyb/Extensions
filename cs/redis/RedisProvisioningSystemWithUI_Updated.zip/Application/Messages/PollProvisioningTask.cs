
public class PollProvisioningTask
{
    public Guid OperationTaskId { get; set; }
}
