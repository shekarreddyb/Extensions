
public class TaskFailed
{
    public Guid OperationTaskId { get; set; }
    public Guid TransactionId { get; set; }
    public Guid DatabaseId { get; set; }
    public Guid ClusterId { get; set; }
    public string Operation { get; set; } = default!;
    public string Message { get; set; } = default!;
}
