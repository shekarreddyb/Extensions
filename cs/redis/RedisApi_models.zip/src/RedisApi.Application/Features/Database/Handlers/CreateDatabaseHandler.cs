using MediatR;
using RedisApi.Application.Interfaces;
using RedisApi.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace RedisApi.Application.Features.Database.Handlers
{
    public class CreateDatabaseHandler : IRequestHandler<CreateDatabaseCommand, Database>
    {
        private readonly IUnitOfWork _unitOfWork;

        public CreateDatabaseHandler(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task<Database> Handle(CreateDatabaseCommand request, CancellationToken cancellationToken)
        {
            var database = new Database
            {
                Id = Guid.NewGuid(),
                AppId = request.AppId,
                Lob = request.Lob,
                Environment = request.Environment,
                Modules = request.Modules,
                Email = request.Email,
                Ticket = request.Ticket,
                CRDB = request.CRDB,
                TlsOu = request.TlsOu,
                TlsCn = request.TlsCn,
                Status = "Pending",
                Datacenters = request.Datacenters.Select(dc => new DatabaseDatacenter
                {
                    Id = Guid.NewGuid(),
                    DatabaseId = database.Id,
                    Datacenter = dc,
                    Uid = (uint)new Random().Next(1000, 9999),
                    Crdt = Guid.NewGuid(),
                    Status = "Pending",
                    Endpoint = $"https://{dc}.redis.example.com",
                    Name = $"{request.AppId}-{dc}"
                }).ToList()
            };

            await _unitOfWork.Databases.AddAsync(database);
            await _unitOfWork.SaveChangesAsync();

            return database;
        }
    }
}
