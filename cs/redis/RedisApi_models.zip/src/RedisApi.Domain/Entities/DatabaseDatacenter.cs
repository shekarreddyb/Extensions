using System;

namespace RedisApi.Domain.Entities
{
    public class DatabaseDatacenter
    {
        public Guid Id { get; set; }
        public Guid DatabaseId { get; set; }
        public string Datacenter { get; set; }
        public uint Uid { get; set; }
        public Guid Crdt { get; set; }
        public string Status { get; set; }
        public string Endpoint { get; set; }
        public string Name { get; set; }
    }
}
