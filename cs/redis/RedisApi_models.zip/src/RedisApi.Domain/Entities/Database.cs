using System;
using System.Collections.Generic;

namespace RedisApi.Domain.Entities
{
    public class Database
    {
        public Guid Id { get; set; }
        public string AppId { get; set; }
        public string Lob { get; set; }
        public string Environment { get; set; }
        public List<string> Modules { get; set; } = new();
        public string Email { get; set; }
        public string Ticket { get; set; }
        public bool CRDB { get; set; }
        public string TlsOu { get; set; }
        public string TlsCn { get; set; }
        public string Status { get; set; }
        public List<DatabaseDatacenter> Datacenters { get; set; } = new();
    }
}
